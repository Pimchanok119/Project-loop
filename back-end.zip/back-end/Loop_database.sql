CREATE DATABASE loop_database;
USE loop_database ;
DROP TABLE IF EXISTS `login_information`;
CREATE TABLE `login_information` (
  `UID` int NOT NULL,
  `Login_log` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT COLLATE=utf8_general_ci;
--

DROP TABLE IF EXISTS `user_information`;
CREATE TABLE `user_information` (
  `UID` int NOT NULL AUTO_INCREMENT,
  `Email` varchar(45) NOT NULL,
  `Firstname` varchar(45) NOT NULL,
  `Lastname` varchar(45) NOT NULL,
  `Username` varchar(45) NOT NULL,
  `Password` varchar(45) NOT NULL,
  `Dob` date NOT NULL,
  `Plan` enum('-','Free','Montly','Year') NOT NULL,
  `Role` enum('ADMIN','USER') NOT NULL default 'USER',
  `regis_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ,
  PRIMARY KEY (`UID`),
  UNIQUE(`Username`)
) ENGINE=InnoDB  DEFAULT COLLATE=utf8_general_ci;

INSERT INTO `user_information`(`Email`, `Firstname`, `Lastname`, `Username`, `Password`, `Dob`, `Plan`, `Role`) VALUES ('admin@admin.com','admin','admin','admin','admin','2022-03-28','-','ADMIN');


--
-- Table structure for table `song_information`
--

DROP TABLE IF EXISTS `song_information`;
CREATE TABLE `song_information` ( 
	`song_id` INT(255) NOT NULL AUTO_INCREMENT , 
	`song_name` VARCHAR(100) NOT NULL , 
	`image` VARCHAR(200) NOT NULL , 
	`artist` VARCHAR(100) NOT NULL , 
	`category` VARCHAR(100) NOT NULL,
	`description` VARCHAR(100) NOT NULL , 
	`create_date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`update_date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (`song_id`))
ENGINE = InnoDB CHARSET=utf8 COLLATE utf8_general_ci;


INSERT INTO `song_information`(`song_name`, `image`, `artist`, `category`, `description`) VALUES ('Beggin','https://i.imgur.com/5pwxIKr_d.webp?maxwidth=760&fidelity=grand','Maneskin','ROCK','Put your loving hand out, baby Cause Im beggin.....');
INSERT INTO `song_information`(`song_name`, `image`, `artist`, `category`, `description`) VALUES ('Calling My Phone','https://i.imgur.com/CujMIKt.jpg','Lil Tjay(feat. 6LACK)','HIP-HOP','Steady callin my phone I done told you before that its over, leave me lone....');
INSERT INTO `song_information`(`song_name`, `image`, `artist`, `category`, `description`) VALUES ('Easy on me','https://i.imgur.com/1dWnM1B.jpg','Adele','POP','There aint no gold in this river.....');
INSERT INTO `song_information`(`song_name`, `image`, `artist`, `category`, `description`) VALUES ('Cold Heart','https://i.imgur.com/l0VzQle.jpg','Elton John & Dua Lipa','POP','Its a human sign When things go wrong....');
INSERT INTO `song_information`(`song_name`, `image`, `artist`, `category`, `description`) VALUES ('Leave the Door Open','https://i.imgur.com/PxluvVi.jpg','Bruno Mars, Anderson .Paak, Silk Sonic','R-AND-B','Said baby, said baby, said baby....');
INSERT INTO `song_information`(`song_name`, `image`, `artist`, `category`, `description`) VALUES ('ZOMBIFIED','https://i.imgur.com/kQkCF8q.jpg','Falling In Reverse','ROCK','The monsters arent living under your bed....');
INSERT INTO `song_information`(`song_name`, `image`, `artist`, `category`, `description`) VALUES ('Straightenin','https://i.imgur.com/N2HjPpQ.png','Migos','HIP-HOP','DJ Durel! (Ayy, Castro go crazy).....');
INSERT INTO `song_information`(`song_name`, `image`, `artist`, `category`, `description`) VALUES ('Gods Country','https://i.imgur.com/0rWNnq1.jpg','Blake Shelton','ROCK','Right outside of this one church town...');